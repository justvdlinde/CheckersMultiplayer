-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 18 jun 2018 om 01:36
-- Serverversie: 5.7.17
-- PHP-versie: 5.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `justvanderlinde`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Gegevens worden uitgevoerd voor tabel `account`
--

INSERT INTO `account` (`id`, `username`, `password`, `fullname`, `email`) VALUES
(1, 'just', '123', 'Just van der Linde', 'just@just.nl'),
(2, 'Test', '12345', 'Test', 'test@Test.com'),
(3, 'danny', '12345', 'Danny Bird', 'dan@dan.com'),
(4, 'juicy J', '123', 'Just van der Linde', 'j@j.com'),
(5, 'bolwerk', '123', 'daan', 'daan@daan.com'),
(6, 'just.vanderlinde@student.hku.n', '123', 'just123', 'just.vanderlinde@student.hku.nl'),
(7, 'alfie', '123', 'Alfred Hansen', 'alf@hotmail.com'),
(8, '', '12345', '', 'justun'),
(9, '', '123', '', 'dandan'),
(10, '', '123', '', 'Jim'),
(11, '', '123', '', 'j@u.com');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Games`
--

CREATE TABLE IF NOT EXISTS `Games` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Gegevens worden uitgevoerd voor tabel `Games`
--

INSERT INTO `Games` (`ID`, `NAME`) VALUES
(2, 'XCOM 2'),
(3, 'The Witcher 8'),
(4, 'Bloodborne');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `scores`
--

CREATE TABLE IF NOT EXISTS `scores` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `player` varchar(30) NOT NULL,
  `game` varchar(30) NOT NULL,
  `score` int(30) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Gegevens worden uitgevoerd voor tabel `scores`
--

INSERT INTO `scores` (`id`, `player`, `game`, `score`, `date`) VALUES
(1, 'just.vanderlinde@student.hku.n', 'Bloodborne', 150, '2018-06-09 21:09:41'),
(2, 'just.vanderlinde@student.hku.n', 'XCOM 2', 123, '2018-06-09 22:03:56'),
(3, 'just.vanderlinde@student.hku.n', 'The Witcher 8', 2134, '2018-06-09 22:04:01'),
(4, 'just.vanderlinde@student.hku.n', 'XCOM 2', 222, '2018-06-09 22:04:04'),
(5, 'just.vanderlinde@student.hku.n', 'The Witcher 8', 44, '2018-06-09 22:04:07'),
(6, 'just.vanderlinde@student.hku.n', 'The Witcher 8', 11234, '2018-06-09 22:04:11'),
(7, 'just.vanderlinde@student.hku.n', 'The Witcher 8', 666, '2018-06-09 23:25:40'),
(8, 'just', 'XCOM 2', 5523, '2018-06-07 00:00:00'),
(9, 'alfie', 'XCOM 2', 99999, '2018-06-10 01:04:15'),
(10, 'just.vanderlinde@student.hku.n', 'Bloodborne', 500, '2018-06-12 10:21:00'),
(11, 'juicy J', 'The Witcher 8', 455, '2018-06-15 10:38:20'),
(12, 'juicy J', 'Bloodborne', 123321, '2018-06-15 10:47:47');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Gegevens worden uitgevoerd voor tabel `Users`
--

INSERT INTO `Users` (`ID`, `EMAIL`, `PASSWORD`) VALUES
(1, 'justvdlinde@hotmail.com', 'fakepassword'),
(9, 'jelle', 'jelle'),
(10, 'unity', 'unity');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
